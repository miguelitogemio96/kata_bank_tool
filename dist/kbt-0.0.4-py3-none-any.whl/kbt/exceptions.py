class EmptyDataError(Exception):
    pass


class DataTypeError(Exception):
    pass


class MapperError(Exception):
    pass


class ProcessError(Exception):
    pass
